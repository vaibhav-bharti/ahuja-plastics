<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('raw_materials', function (Blueprint $table) {

            $table->id();

            $table->string('name');

            $table->enum('type', [
                'Fresh',
                'Reused',
            ]);

            $table->boolean('status')->default(true);

            $table->text('remarks')->nullable();

            $table->timestamps();

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('raw_materials');
    }
};